<?php

	class Liber
	{
		public $arrRunes;
		public $arrLetters;
		public $strWordDelimiter;

		public function __construct ()
		{
			$this->arrRunes = array
			(
				2	=> '16a0', // ᚠ
				3	=> '16a2', // ᚢ
				5	=> '16a6', // ᚦ
				7	=> '16a9', // ᚩ
				11	=> '16b1', // ᚱ
				13	=> '16b3', // ᚳ
				17	=> '16b7', // ᚷ
				19	=> '16b9', // ᚹ
				23	=> '16bb', // ᚻ
				29	=> '16be', // ᚾ
				31	=> '16c1', // ᛁ
				37	=> '16c4', // ᛄ
				41	=> '16c7', // ᛇ
				43	=> '16c8', // ᛈ
				47	=> '16c9', // ᛉ
				53	=> '16cb', // ᛋ
				59	=> '16cf', // ᛏ
				61	=> '16d2', // ᛒ
				67	=> '16d6', // ᛖ
				71	=> '16d7', // ᛗ
				73	=> '16da', // ᛚ
				79	=> '16dd', // ᛝ
				83	=> '16df', // ᛟ
				89	=> '16de', // ᛞ
				97	=> '16aa', // ᚪ
				101	=> '16ab', // ᚫ
				103	=> '16a3', // ᚣ
				107	=> '16e1', // ᛡ
				109	=> '16e0'  // ᛠ
			);

			$this->arrLetters = array
			(
				2	=>	'0046',
				3	=>	'0055002f0056',
				5	=>	'00540048',
				7	=>	'004f',
				11	=>	'0052',
				13	=>	'0043002f004b',
				17	=>	'0047',
				19	=>	'0057',
				23	=>	'0048',
				29	=>	'004e',
				31	=>	'0049',
				37	=>	'004a',
				41	=>	'0045004f',
				43	=>	'0050',
				47	=>	'0058',
				53	=>	'0053002f005a',
				59	=>	'0054',
				61	=>	'0042',
				67	=>	'0045',
				71	=>	'004d',
				73	=>	'004c',
				79	=>	'004e0047002f0049004e0047',
				83	=>	'004f0045',
				89	=>	'0044',
				97	=>	'0041',
				101	=>	'00410045',
				103	=>	'0059',
				107	=>	'00490041002f0049004f',
				109	=>	'00450041'
			);

			$this->intGematriaSize = sizeof ($this->arrLetters);
			$this->strWordDelimiter = '0020';
		}

		/*
		@	Shift Gematria key by offset
		*/
		public function ShiftKey ($intOffset = 0)
		{
			$intOffset = ($intOffset > $this->intGematriaSize) ? ($intOffset % $this->intGematriaSize) : $intOffset;
			$arrKeys = array_keys ($this->arrLetters);
			$arrValues = array_values ($this->arrLetters);

			for ($i = 0; $i < $intOffset; $i ++)
			{
				array_unshift ($arrValues, array_pop ($arrValues));
			}

			$this->arrLetters = array_combine ($arrKeys, $arrValues);
			return true;
		}

		/*
		@	Reverse Gematria
		*/
		public function ReverseKey ()
		{
			$this->arrLetters = array_combine (array_keys ($this->arrLetters), array_reverse (array_values ($this->arrLetters)));
		}

		/*
		@	Calculate the index of coincidence of string
		@	return float;
		*/
		public function CalculateIC ($strString = '')
		{
			// Get length of string
			$intStrLength = mb_strlen (trim ($strString), 'UTF-8');
			//var_dump ($intStrLength);

			// Split string to single characters
			$arrChars = preg_split ('//u', $strString, -1, PREG_SPLIT_NO_EMPTY);
			//var_dump ($arrChars);

			// Count char frequency exclude space
			$arrCharCount = array_count_values (array_filter (array_map ('trim', $arrChars)));
			//var_dump ($arrCharCount);

			foreach ($arrCharCount as $strChar => $intCount)
			{
				$foo[] = $intCount * ($intCount - 1);
			}

			$intFooSum = array_sum ($foo);
			$intCharSum = array_sum ($arrCharCount);

			return $intFooSum / ($intCharSum * ($intCharSum - 1));

		}

		public function Translate ($strString = '')
		{
			// Split string to single characters
			$arrChars = preg_split ('//u', $strString, -1, PREG_SPLIT_NO_EMPTY);
			//var_dump ($arrChars);

			foreach ($arrChars as $j => $strChar)
			{
				// Convert rune to codepoint and get its key from rune mapping
				// Map rune to letter and add word dilimiter
				$arrASCII[] = $this->CodePointToChar ((($arrKeys[$j] = array_search ($this->CharToCodePoint ($strChar), $this->arrRunes)) === false) ? $this->strWordDelimiter : $this->arrLetters[$arrKeys[$j]]);
			}

			print_r ($arrASCII);
		}

		/*
		@	Find sequence in string and return its offset(s)
		@	return array ($intPosition_1, $intPosition_2, $intPosition_n);
		@	TODO: Add/Fix whitespaces
		*/
		public function FindSequence ($strString = '', $strSequence = '', $intOffset = 0, $blnStrict = 0)
		{
			$strString = ($blnStrict === 1) ? $strString : preg_replace ('/[ \t]/', '', $strString);
			$arrOffsets = array ();
			$intSeqLen = mb_strlen ($strSequence, 'UTF-8');

			while (($intStrPos = mb_strpos ($strString, $strSequence, $intOffset, 'UTF-8')) !== false)
			{
				$arrOffsets[] = $intStrPos;
				$intOffset = ($blnStrict === 1) ? $intStrPos + $intSeqLen : $intStrPos + 1;
			}

			return $arrOffsets;

		}

		/*
		@	Take string and return n-grams with length offset
		@	return array ($strNGram_1, $strNGram_2, $strNGram_n);
		*/
		public function BuildNGrams ($strString = '', $intOffset = 0)
		{
			// Split string to single chars obmitting space
			$foo =  array_values (array_filter (array_map ('trim', preg_split ('//u', $strString, -1, PREG_SPLIT_NO_EMPTY))));
			//print_r ($foo);

			$intOffset = ($intOffset > sizeof ($foo)) ? sizeof ($foo) : $intOffset;

			for ($i = 0; $i <= (sizeof ($foo) - $intOffset); $i ++)
			{
				$bar[] = implode ('', array_slice ($foo, $i, $intOffset));
			}

			return array_unique ($bar, SORT_LOCALE_STRING);
		}

		/*
		@	Take character and return its codepoint
		@	return string;
		*/
		public function CharToCodePoint ($strChar = '')
		{
			return implode (unpack ('H*', iconv ("UTF-8", "UCS-2BE", $strChar)));
		}

		/*
		@	Take codepoint and return its character
		@	return string;
		*/
		public function CodePointToChar ($strCodepoint = '')
		{
			return iconv ("UCS-2BE", "UTF-8", pack ('H*', $strCodepoint));
		}

		/*
		@	Take char and return its binary representation
		@	return string;
		*/
		public function CharToBinary ($strChar = '', $blnAddPadding = true)
		{
			return str_pad (base_convert ($strChar, 16, 2), (($blnAddPadding) ? 4 : 0), 0, STR_PAD_LEFT);
		}

	}

	//$strText = 'ᛄᚱᛠᛝᚱᛝᛠᛠᛗᚱ ᛝᛠ';
	//$strText = 'ᚱ ᛝᚱᚪᛗᚹ ᛄᛁᚻᛖᛁᛡᛁ ᛗᚫᚣᚹ ᛠᚪᚫᚾ ᚣᛖᛈ ᛄᚫᚫᛞ ᛁᛉᛞᛁᛋᛇ ᛝᛚᚱᛇ ᚦᚫᛡ ᛞᛗᚫᛝ ᛇᚫ ᛄᛁ ᛇᚪᛡᛁ ᛇᛁᛈᛇ ᚣᛁ ᛞᛗᚫᛝᚻᛁᚳᛟᛁ ᛠᛖᛗᚳ ᚦᚫᛡᚪ ᛇᚪᛡᚣ ᛁᛉᛋᛁᚪᛖᛁᛗᛞᛁ ᚦᚫᛡᚪ ᚳᚠᚣ ᚳᚫ ᛗᚫᛇ ᛁᚳᛖᛇ ᚫᚪ ᛞᛚᚱᚹᛁ ᚣᛖᛈ ᛄᚫᚫᛞ ᚫᚪ ᚣᛁ ᚾᛁᛈᛈᚱᛟᛁ ᛞᚫᛗᛇᚱᛖᛗᛁᚳ ᛝᛖᚣᛖᛗ ᛁᛖᚣᛁᚪ ᚣᛁ ᛝᚫᚪᚳᛈ ᚫᚪ ᚣᛁᛖᚪ ᛗᛡᚾᛄᛁᚪᛈ ᛠᚫᚪ ᚱᚻᚻ ᛖᛈ ᛈᚱᛞᚪᛁᚳ';
	//$strText = 'ᛋᚻᛖᚩᚷᛗᛡᚠ ᛋᚣᛖᛝᚳ ᚦᛂᚷᚫ ᚠᛂᛟ ᚩᚾᚦ ᚾᛖᚹᛒᚪᛋᛟᛇᛁᛝᚢ ᚾᚫᚷᛁᚦ ᚻᛒᚾᛡ ᛈᛒᚾ ᛇᛂᚦ ᚪᛝᚣᛉ ᛒᛞᛈ ᛖᛡᚠᛉᚷᚠ ᛋᛈᛏᚠᛈᚢᛝᚣᛝᛉᛡ ᚣᚻ ᛒᚢ ᚷᚩᛈ ᛝᚫᚦ ᛁᚫᚻᛉᚦᛈᚷ ᚣᚠᛝᚳᛂ ᚦᚪᛗᛁᛝᛁᛡᚣ ᚻᛇ ᛏᚻᚫᛡ ᛉᚣ ᛖᚢᛝ ᚳᚠᚾ ᛇᚦᛂᛁᚦ ᚦᛈ ᚣᛝᛠ ᚣᚾᛖᚣ ᛞᛉᛝᚹ ᛒᚳᛉᛞᛒᚠ ᛗᛏᚾᛖ ᛠᛂᚾᛚᚷᛒ ᛉᚷᚦ ᚣᛁᛞᚪ ᛝᚷᛗᛂᚱᚩᛚᛇ ᚣᛏᛈᛁᚦᛞᛂ ᛟᚻᛚ ᛠ ᚠᛉᚫᛈᚷᛉ ᚠᛚᚹᛇᛏᚫ ᚠᚷᚾ ᛗᛇᛚᚾ ᛝᛗᚠᚱᛡ ᚪᛋ ᛠᛗᛝᛉᛉᛇᛞᛒ ᛟᛞᛗᚩ ᛠᛇᚻ ᛞᛝᚷ ᛟᛝᛚᚢᚱᚾᛏ ᚫᛋᚣᚢᚻᚱᛏ ᚻᚳ ᛋᛟᛏᛟᛝᚢᚱ ᛋ ᚠᚩᛖᚹᛠᛟᛚᚠᚫ ᛗᚱᛝ ᛞᚪᛗᚱ ᚹᚪᛁᛗᛋᚾ ᛋᛟᚱᚢᚹᛋᛚᛡ ᛟᚪᚫᛝᛋᛞᛈᛏ ᚳᚱᚦᛡ ᚱᛒᚩᛞᚦᚠ ᚣᛉᛁᛏ ᛟᛁ ᚠᛚᚩ ᚠᛠ ᚱᚩᛟᛗᚻᛗᚷᛈᚻ ᚫᚻᚾᚩᚻᚣ ᛟᛋᛚ ᚾᚷ ᚫᚣ ᛟᚳᛒᛚᛂ ᛝᛚᛟ ᚫᛂᛠᚹ ᛠᚦᚩ ᛒᛟᚣ ᚳᚠᚳᛂ ᛚᚫ ᚾ ᚦᛈ ᚢᛉ ᛟᛉᚷ ᛈᚠᛋᛇᚫᛟ ᛝᛈᛇᚩᛖᚪ ᚷᚫᛡᛝᚦᚩ ᛈᚪᛟᚦᚱᛝᚫ ᚳᛋᛒᛇᚣᚻ ᛏᛉᛖᛚᚱ ᚷᚹᚣ ᛂᚠᛁᚾᛡᚳᚣᛠᛁᛡ ᚩᚦ ᛖᚳᚫᚳᛉᛡᛠ ᚩᛚᚳ ᚠᚱᛞᛝᛖᚢ ᛞᚳᛚᛠᛋᛉᚳᚷᛡ ᚹᛋᚦ ᚠᛞᛝ ᛁᛡᛗᚪᚫᚷ ᚹᛋ ᚾᛞ ᚳᛈᚦᛉᛈᛠᛠ ᚹᚢ ᛠᚹ ᚠᚹᛂᚣ ᛉᛞᚹᚳᚷᚳᛟ ᛞᛉᛟ ᚱᛡᚷ ᚾᛈᚪᚣᛈ ᚳᚣᚻ ᚠᛖᛂᛠᚾ ᛟᚫ ᚢᚪ ᚻᚱ ᛖᛠᚦᚠᛂᚪ ᛚᛉᛋᛏ ᛗᚠᛚᚠᛏ ᚷᛁᚦ ᚢᛚᚷ ᛉᛠᛏᛋᛚᛂᛈ ᛚᛉᛁᛟᛗ ᚢ ᚻᛏ ᛒᛇᛚᛞᚻᛒᛗ ᛠᚱᛒ ᚾᚻᛒᛖᚷᛇ ᛞᛚᚹᛇᛡᛈᚩ ᚻᛖᛠ ᚹᛁᚱᛁᚻ ᚢᚦᚻᚣ ᚾᛉᛒᚷᛂᛈᚢ ᛝᛠᚠᚾᛁᛖᛞᛡᛝᚱ ᛞᛒᛂᛡᛟᛗᛁ ᚠᛏ ᛂᛞᛁᚦᚱᛚᛋ ᛖᛇᚩᚷᛒᛏᛞ ᚦᚪᚾᚳᚣ ᛡᛋᚦᛞ ᛝᚠᛚᛖᚷᚻᚳ ᛖᚩᛁᛏᚾᛉ ᛈᛏᚠᚻᚱᛞᛖᚠᛏ ᚫᚹᚻ ᛒᚳ ᚠ ᛈᚪᛚᚢᛠᚾᛚᛂ ᛂᚳᛚᚹᛠᛞᚢᛞᛇ ᛠᛉᛞᚹᚻᛠ ᚦᛡᚫᚳᛚᛏᚹᛖᛁᚳ ᛈᛟᛞᚳ ᚾᚻᚪ ᚱᛁᚷᚦᛠᛖᛏᚷ ᚦᚻᚩᛡᚹᚫᛂᛖ ᛝᛠᛞ ᚩᚫ ᚪᛚ ᛒᛂᚳᚢᛉᛏᚪᛒᛂᛈ ᚠᛠ ᚻᛞᚾᛡᚢᛈᛋᚢᚹ';

	$L = new Liber ();
	$L->Shift




	//echo ((round ($L->CalculateIC ($strText), 6)) * 100)."%";
	//$L->ReverseKey ();
	//$L->Translate ($strText);
	//print_r ($L->BuildNGrams ($strText, 8));
	//print_r ($L->FindSequence ($strText, 'ᚣᛖᛈ'));


	/*
	$foo = $L->BuildNGrams ($strText, 3, 0, 0);

	$foobar = array ();
	foreach ($foo as $key => $value)
	{
		$bar = $L->FindSequence ($strText, $value);
		if (sizeof ($bar) > 1) $foobar[$value] = $bar;
	}

	print_r($foobar);
	*/

?>